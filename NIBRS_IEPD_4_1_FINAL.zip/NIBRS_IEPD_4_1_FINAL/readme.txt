NIEM MPD NIBRS 4.1 IEPD

Contents:
1.  nibrs_MasterDocumentation.docx			XML System Specification File (docx)
2.  nibrs_XMLMapping_Spreadsheet.xlsx				MPD Specification 3.0 (xlsx)
3.  mpd-catalog.xml                 MPD Catalog file (xml)
4.  nibrs_UML.pdf					UML Diagram (pdf)
5.  nibrs_CodeTables.xlsx				Code Tables for each Instance (xlsx)
6.  nibrs_ConformanceAssertion.txt		Example conformance assertion (txt)
7.  changelog.txt           Listing of changes made to IEPD from last version (txt)
8.  IEP Sample Files
    *  nibrs_AllFields_Sample.xml  (xml)
    *  nibrs_GroupAReplace_Sample.xml  (xml)
    *  nibrs_GroupBArrest_Sample.xml  (xml)
    *  nibrs_GroupBArrestDelete_Sample.xml  (xml)
    *  nibrs_IncidentDelete_Sample.xml  (xml)
    *  nibrs_ZeroReport_Sample.xml  (xml)
9. CJIS Domain XSD Files
   *cjis.xsd  (xsd)
   *cjis-codes.xsd  (xsd)
10.  NIBRS Domain XSD Files
    *  nibrs.xsd  (xsd)
    *  nibrs-codes.xsd  (xsd)
11.  readme.txt					(this file)