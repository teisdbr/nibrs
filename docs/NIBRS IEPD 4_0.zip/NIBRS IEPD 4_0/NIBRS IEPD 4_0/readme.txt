NIEM MPD NIBRS 4.0 IEPD

Contents:
1.  nibrsMasterDocumentation.docx			XML Specification File (docx)
2.  nibrsNIEM_Mapping.xlsx				MPD Specification 3.0 (xlsx)
3.  nibrsUML.pdf					UML Diagram (pdf)
4.  nibrsCodeTables.xlsx				Code Tables for each Instance (xlsx)
5.  nibrsNIEMConformanceAssertion.docx		Example conformance assertion (docx)
6.  readme.txt					(this file)

